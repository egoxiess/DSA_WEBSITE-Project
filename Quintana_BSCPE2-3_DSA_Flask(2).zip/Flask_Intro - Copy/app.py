from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/profile')
def profile():
    return render_template('profile.html')

@app.route('/works')
def works():
    return render_template('works.html')

@app.route('/touppercase', methods=['GET', 'POST'])
def to_uppercase():
    result = None
    if request.method == 'POST':
        input_string = request.form.get('inputString', '')
        result = input_string.upper()
    return render_template('touppercase.html', result=result)

@app.route('/contact')
def contact():
    return render_template('contacts.html')

@app.route('/AreaofaCircle', methods=['GET', 'POST'])
def area_of_circle():
    area = None
    error = None
    if request.method == 'POST':
        try:
            radius = int(request.form.get('radius', 0))
            area = 3.14159 * radius * radius
        except ValueError:
            error = "Please enter a valid integer for the radius."
    return render_template('AreaofaCircle.html', area=area, error=error)

@app.route('/AreaofTriangle', methods=['GET', 'POST'])
def area_of_triangle():
    area = None
    error = None
    if request.method == 'POST':
        try:
            base = float(request.form.get('base', 0))
            height = float(request.form.get('height', 0))
            area = 0.5 * base * height
        except ValueError:
            error = "Please enter valid numbers for base and height."
    return render_template('AreaofTriangle.html', area=area, error=error)   

# def area_of_triangle():
#     area = None
#     error = None
#     if request.method == 'POST':
#         try:
#             radius = int(request.form.get('radius', 0))
#             area = 3.14159 * radius * radius
#         except ValueError:
#             error = "Please enter a valid integer for the radius."
#     return render_template('AreaofaCircle.html', area=area, error=error)

if __name__ == "__main__":
    app.run(debug=True)

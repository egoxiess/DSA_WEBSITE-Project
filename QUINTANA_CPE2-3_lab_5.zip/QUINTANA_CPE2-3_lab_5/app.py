from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/profile')
def profile():
    return render_template('profile.html')

@app.route('/works')
def works():
    return render_template('works.html')

@app.route('/touppercase', methods=['GET', 'POST'])
def to_uppercase():
    result = None
    if request.method == 'POST':
        input_string = request.form.get('inputString', '')
        result = input_string.upper()
    return render_template('touppercase.html', result=result)

@app.route('/contact')
def contact():
    return render_template('contacts.html')

@app.route('/AreaofaCircle', methods=['GET', 'POST'])
def area_of_circle():
    area = None
    error = None
    if request.method == 'POST':
        try:
            radius = int(request.form.get('radius', 0))
            area = 3.14159 * radius * radius
        except ValueError:
            error = "Please enter a valid integer for the radius."
    return render_template('AreaofaCircle.html', area=area, error=error)

@app.route('/AreaofTriangle', methods=['GET', 'POST'])
def area_of_triangle():
    area = None
    error = None 
    if request.method == 'POST':
        try:
            base = float(request.form.get('base', 0))
            height = float(request.form.get('height', 0))
            area = 0.5 * base * height
        except ValueError:
            error = "Please enter valid numbers for base and height."
    return render_template('AreaofTriangle.html', area=area, error=error)

@app.route('/InfixToPostfix', methods=['GET', 'POST'])
def infix_to_postfix():
    result = None
    error = None
    if request.method == 'POST':
        expression = request.form.get('expression', '').replace(" ", "")
        try:
            precedence = {'+': 1, '-': 1, '*': 2, '/': 2, '^': 3}
            stack = []
            output = []
            for char in expression:
                if char.isalnum():
                    output.append(char)
                elif char == '(':
                    stack.append(char)
                elif char == ')':
                    while stack and stack[-1] != '(':
                        output.append(stack.pop())
                    if stack:
                        stack.pop()
                else:
                    while (stack and stack[-1] != '(' and
                           precedence.get(char, 0) <= precedence.get(stack[-1], 0)):
                        output.append(stack.pop())
                    stack.append(char)
            while stack:
                output.append(stack.pop())
            result = ' '.join(output)
        except Exception as e:
            error = str(e)
    return render_template('InfixToPostfix.html', result=result, error=error)



if __name__ == "__main__":
    app.run(debug=True)
